const videoElement = document.getElementById('input_video');
const canvasElement = document.getElementById('output_canvas');
const canvasCtx = canvasElement.getContext('2d');
const startButton = document.getElementById('start_button');
const pauseButton = document.getElementById('pause_button');
const calibrateButton = document.getElementById('calibrate_button');
const saveButton = document.getElementById('save_button');
const phaseLabel = document.getElementById('phase_label');
const repCountLabel = document.getElementById('rep_count');
const scoreLabel = document.getElementById('score_label');
const errorsLabel = document.getElementById('errors_label');
const historyList = document.getElementById('history_list');
const clearHistoryButton = document.getElementById('clear_history_button');
const sessionNameInput = document.getElementById('session_name');

let camera = null;
let running = false;
let calibrated = false;
let baselineHipY = null;
let phase = 'STANDING';
let currentRep = null;
let repHistory = [];
let minKnee = 180;
let lastScore = 0;
let sessionStart = Math.floor(Date.now() / 1000);

const POSE_CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 7],
  [0, 4], [4, 5], [5, 6], [6, 8],
  [9, 10],
  [11, 12], [11, 13], [13, 15], [15, 17], [15, 21], [17, 19], [19, 21],
  [12, 14], [14, 16], [16, 18], [16, 22], [18, 20], [20, 22],
  [11, 23], [12, 24], [23, 24],
  [23, 25], [25, 27], [27, 29],
  [24, 26], [26, 28], [28, 30], [29, 31], [30, 32]
];

const pose = new Pose({
  locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.5/${file}`
});
pose.setOptions({
  modelComplexity: 1,
  smoothLandmarks: true,
  minDetectionConfidence: 0.55,
  minTrackingConfidence: 0.55,
  selfieMode: true
});
pose.onResults(onResults);

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function toDegrees(radians) {
  return radians * (180 / Math.PI);
}

function calcAngle(a, b, c) {
  const ab = [a.x - b.x, a.y - b.y];
  const cb = [c.x - b.x, c.y - b.y];
  const dot = ab[0] * cb[0] + ab[1] * cb[1];
  const mag = Math.sqrt(ab[0] * ab[0] + ab[1] * ab[1]) * Math.sqrt(cb[0] * cb[0] + cb[1] * cb[1]);
  if (mag < 1e-6) return 0;
  return toDegrees(Math.acos(clamp(dot / mag, -1, 1)));
}

function calcAngleVertical(a, b) {
  const vec = [b.x - a.x, b.y - a.y];
  const vertical = [0, -1];
  const dot = vec[0] * vertical[0] + vec[1] * vertical[1];
  const mag = Math.sqrt(vec[0] * vec[0] + vec[1] * vec[1]) * Math.sqrt(1);
  if (mag < 1e-6) return 0;
  return toDegrees(Math.acos(clamp(dot / mag, -1, 1)));
}

function getMetricColor(value) {
  if (value === null || value === undefined) return 'var(--muted)';
  if (value <= 95) return 'var(--good)';
  if (value <= 120) return 'var(--warn)';
  return 'var(--bad)';
}

function updateMetric(id, value, suffix = '°') {
  const element = document.getElementById(id);
  if (!element) return;
  element.textContent = typeof value === 'number' ? `${value.toFixed(0)}${suffix}` : `${value}${suffix}`;
}

function updatePhaseLabel() {
  phaseLabel.textContent = phase;
}

function updateSummary(metrics, errors, score) {
  repCountLabel.textContent = repHistory.length;
  scoreLabel.textContent = score;
  errorsLabel.textContent = errors.length ? errors.join(', ') : 'None';
  updateMetric('left_knee', metrics.leftKnee);
  updateMetric('right_knee', metrics.rightKnee);
  updateMetric('left_hip', metrics.leftHip);
  updateMetric('right_hip', metrics.rightHip);
  updateMetric('torso_lean', metrics.torsoLean);
  updateMetric('back_posture', Math.min(metrics.leftBack, metrics.rightBack));
  updateMetric('knee_over_toe', metrics.kneeOverToe, '');
}

function evaluateRep(metrics) {
  const errors = [];
  let score = 100;

  if (metrics.kneeWidthRatio < 0.75) {
    errors.push('Knee cave');
    score -= 20;
  }
  if (metrics.torsoLean > 45) {
    errors.push('Forward lean');
    score -= 15;
  }
  if (Math.min(metrics.leftBack, metrics.rightBack) < 145) {
    errors.push('Back rounding');
    score -= 15;
  }
  if (metrics.kneeOverToe > 0.18) {
    errors.push('Knee over toe');
    score -= 12;
  }
  if (metrics.avgKnee < 120 && metrics.avgKnee > 100) {
    errors.push('Shallow squat');
    score -= 10;
  }
  if (metrics.hipLevelDiff > 0.04) {
    errors.push('Uneven hips');
    score -= 10;
  }
  if (metrics.neckAngle > 35) {
    errors.push('Neck forward');
    score -= 5;
  }
  const avgAnkle = (metrics.leftAnkle + metrics.rightAnkle) / 2;
  if (avgAnkle < 65) {
    errors.push('Heel rise');
    score -= 10;
  }
  const symDiff = Math.abs(metrics.leftKnee - metrics.rightKnee);
  if (symDiff > 12) {
    score -= Math.round(symDiff / 1.5);
  }
  return { errors, score: Math.max(0, Math.min(100, score)) };
}

function computeMetrics(landmarks) {
  const leftHip = landmarks[23];
  const rightHip = landmarks[24];
  const leftKnee = landmarks[25];
  const rightKnee = landmarks[26];
  const leftAnkle = landmarks[27];
  const rightAnkle = landmarks[28];
  const leftFoot = landmarks[31];
  const rightFoot = landmarks[32];
  const leftShoulder = landmarks[11];
  const rightShoulder = landmarks[12];
  const nose = landmarks[0];

  const metrics = {
    leftKnee: calcAngle(leftHip, leftKnee, leftAnkle),
    rightKnee: calcAngle(rightHip, rightKnee, rightAnkle),
    leftHip: calcAngle(leftShoulder, leftHip, leftKnee),
    rightHip: calcAngle(rightShoulder, rightHip, rightKnee),
    leftAnkle: calcAngle(leftKnee, leftAnkle, leftFoot),
    rightAnkle: calcAngle(rightKnee, rightAnkle, rightFoot),
    leftBack: calcAngle(leftShoulder, leftHip, leftKnee),
    rightBack: calcAngle(rightShoulder, rightHip, rightKnee),
    kneeOverToe: Math.max(Math.abs(leftKnee.x - leftAnkle.x) / Math.max(Math.abs(leftHip.x - leftAnkle.x), 1e-6),
                         Math.abs(rightKnee.x - rightAnkle.x) / Math.max(Math.abs(rightHip.x - rightAnkle.x), 1e-6)),
    torsoLean: calcAngleVertical({ x: (leftHip.x + rightHip.x) / 2, y: (leftHip.y + rightHip.y) / 2 },
                                { x: (leftShoulder.x + rightShoulder.x) / 2, y: (leftShoulder.y + rightShoulder.y) / 2 }),
    neckAngle: calcAngleVertical({ x: (leftShoulder.x + rightShoulder.x) / 2, y: (leftShoulder.y + rightShoulder.y) / 2 }, nose),
    kneeWidthRatio: Math.abs(leftKnee.x - rightKnee.x) / Math.max(Math.abs(leftHip.x - rightHip.x), 1e-6),
    hipLevelDiff: Math.abs(leftHip.y - rightHip.y) / Math.max(Math.abs(leftHip.x - rightHip.x), 1e-6),
    shoulderLevel: Math.abs(leftShoulder.y - rightShoulder.y),
  };
  metrics.avgKnee = (metrics.leftKnee + metrics.rightKnee) / 2;
  return metrics;
}

function onResults(results) {
  canvasElement.width = videoElement.videoWidth;
  canvasElement.height = videoElement.videoHeight;
  canvasCtx.save();
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);

  if (!results.poseLandmarks) {
    canvasCtx.restore();
    return;
  }

  drawConnectors(canvasCtx, results.poseLandmarks, POSE_CONNECTIONS, { color: '#38bdf8', lineWidth: 2 });
  drawLandmarks(canvasCtx, results.poseLandmarks, { color: '#fff', lineWidth: 1, radius: 2 });

  const metrics = computeMetrics(results.poseLandmarks);
  if (calibrated && baselineHipY === null) {
    baselineHipY = (results.poseLandmarks[23].y + results.poseLandmarks[24].y) / 2;
  }

  const state = performPhaseAnalysis(metrics);
  const evaluation = evaluateRep(metrics);
  lastScore = evaluation.score;

  updatePhaseLabel();
  updateSummary(metrics, evaluation.errors, lastScore);
}

function performPhaseAnalysis(metrics) {
  const avgKnee = metrics.avgKnee;
  if (phase === 'STANDING' && avgKnee < 155) {
    phase = 'DESCENDING';
    minKnee = avgKnee;
    currentRep = { timestamp: Math.floor(Date.now() / 1000), phase: 'DESCENDING', metrics: null };
  } else if (phase === 'DESCENDING') {
    minKnee = Math.min(minKnee, avgKnee);
    if (avgKnee < 100) {
      phase = 'BOTTOM';
      currentRep.phase = 'BOTTOM';
    }
  } else if (phase === 'BOTTOM' && avgKnee > 110) {
    phase = 'ASCENDING';
    currentRep.phase = 'ASCENDING';
  } else if (phase === 'ASCENDING' && avgKnee > 145) {
    phase = 'STANDING';
    currentRep.phase = 'STANDING';
    const evaluation = evaluateRep(metrics);
    repHistory.push({
      timestamp: Math.floor(Date.now() / 1000),
      phase: 'COMPLETE',
      left_knee: metrics.leftKnee,
      right_knee: metrics.rightKnee,
      left_hip: metrics.leftHip,
      right_hip: metrics.rightHip,
      left_ankle: metrics.leftAnkle,
      right_ankle: metrics.rightAnkle,
      left_back: metrics.leftBack,
      right_back: metrics.rightBack,
      knee_over_toe: metrics.kneeOverToe,
      torso_lean: metrics.torsoLean,
      neck_angle: metrics.neckAngle,
      knee_width_ratio: metrics.kneeWidthRatio,
      hip_level_diff: metrics.hipLevelDiff,
      shoulder_level: metrics.shoulderLevel,
      errors: evaluation.errors,
      score: evaluation.score,
    });
    currentRep = null;
  }
  return metrics;
}

function startCamera() {
  if (camera) return;

  camera = new Camera(videoElement, {
    onFrame: async () => {
      if (!running) return;
      await pose.send({ image: videoElement });
    },
    width: 960,
    height: 540
  });
  camera.start();
}

function startSession() {
  if (!running) {
    running = true;
    sessionStart = Math.floor(Date.now() / 1000);
    phase = 'STANDING';
    repHistory = [];
    minKnee = 180;
    currentRep = null;
    updatePhaseLabel();
    repCountLabel.textContent = '0';
    scoreLabel.textContent = '0';
    errorsLabel.textContent = 'None';
    startCamera();
  }
}

function pauseSession() {
  running = false;
}

function calibratePose() {
  if (!videoElement || !videoElement.videoWidth) return;
  calibrated = true;
  baselineHipY = null;
  alert('Calibration complete. Stand upright and keep your body centered in the frame.');
}

async function loadHistory() {
  try {
    const response = await fetch('/api/history');
    if (!response.ok) throw new Error('Could not load history');
    const data = await response.json();
    historyList.innerHTML = '';
    if (!data.sessions || data.sessions.length === 0) {
      historyList.innerHTML = '<p>No saved sessions yet.</p>';
      return;
    }
    data.sessions.forEach((session) => {
      const item = document.createElement('div');
      item.className = 'history-item';
      item.innerHTML = `
        <div class="history-main">
          <div>
            <strong>${session.name}</strong>
            <p>Reps: ${session.total_reps} · Avg score: ${session.avg_score.toFixed(0)}</p>
            <p>Started: ${new Date(session.started_at).toLocaleString()}</p>
          </div>
          <button class="delete-session-button">Delete</button>
        </div>
      `;
      const deleteButton = item.querySelector('.delete-session-button');
      deleteButton.addEventListener('click', () => deleteSession(session.id));
      historyList.appendChild(item);
    });
  } catch (error) {
    historyList.innerHTML = '<p>Unable to load session history.</p>';
    console.error(error);
  }
}

async function deleteSession(sessionId) {
  if (!confirm('Delete this saved session? This action cannot be undone.')) {
    return;
  }

  try {
    const response = await fetch(`/api/delete_session/${sessionId}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Could not delete session');
    await response.json();
    loadHistory();
  } catch (error) {
    console.error(error);
    alert('Unable to delete session. Please try again.');
  }
}

async function clearHistory() {
  if (!confirm('Clear all saved sessions? This will remove all stored user session data.')) {
    return;
  }

  try {
    const response = await fetch('/api/clear_history', {
      method: 'POST',
    });
    if (!response.ok) throw new Error('Could not clear history');
    await response.json();
    loadHistory();
  } catch (error) {
    console.error(error);
    alert('Unable to clear history. Please try again.');
  }
}

async function saveSession() {
  if (!repHistory.length) {
    alert('No reps recorded yet. Perform at least one squat rep before saving.');
    return;
  }
  const sessionName = sessionNameInput.value.trim() || 'AI Squat Session';
  const avgScore = repHistory.reduce((sum, rep) => sum + rep.score, 0) / repHistory.length;
  const payload = {
    name: sessionName,
    started_at: sessionStart,
    total_reps: repHistory.length,
    avg_score: avgScore,
    reps: repHistory
  };

  const response = await fetch('/api/save_session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const result = await response.json().catch(() => null);
    throw new Error(result?.error || 'Unable to save session.');
  }

  const result = await response.json();
  if (result.success) {
    alert('Session saved successfully!');
    repHistory = [];
    repCountLabel.textContent = '0';
    scoreLabel.textContent = '0';
    loadHistory();
  } else {
    alert(result.error || 'Unable to save session.');
  }
}

startButton.addEventListener('click', startSession);
pauseButton.addEventListener('click', pauseSession);
calibrateButton.addEventListener('click', calibratePose);
saveButton.addEventListener('click', saveSession);
clearHistoryButton.addEventListener('click', clearHistory);

loadHistory();
